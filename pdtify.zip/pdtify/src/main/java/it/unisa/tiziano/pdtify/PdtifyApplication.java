package it.unisa.tiziano.pdtify;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PdtifyApplication {

	public static void main(String[] args) {
		SpringApplication.run(PdtifyApplication.class, args);
	}

}
